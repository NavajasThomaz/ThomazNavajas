"use client"

import type React from "react"

import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Send, Sparkles, User, Bot } from "lucide-react"
import { useEffect, useRef } from "react"
import { useLanguage } from "@/lib/language-context"

const suggestedQuestions = [
  "What's your experience with data pipelines?",
  "Tell me about your technical skills",
  "What projects have you worked on?",
  "What tools do you use for ETL?",
]

export function ChatInterface() {
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const { t } = useLanguage()
  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const input = inputRef.current?.value
    if (!input?.trim()) return

    sendMessage({ text: input })
    if (inputRef.current) {
      inputRef.current.value = ""
    }
  }

  const handleSuggestedQuestion = (question: string) => {
    sendMessage({ text: question })
  }

  return (
    <Card className="mx-auto w-full overflow-hidden border-2">
      <div className="flex items-center gap-2 border-b bg-muted/30 px-4 py-3">
        <Sparkles className="h-5 w-5 text-primary" />
        <span className="text-sm font-semibold sm:text-base">{t("aiAssistant")}</span>
        <span className="ml-auto text-xs text-muted-foreground">
          {status === "in_progress" ? t("typing") : t("online")}
        </span>
      </div>

      <div className="h-[400px] overflow-y-auto p-3 sm:h-[500px] sm:p-4">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-4">
            <div className="rounded-full bg-primary/10 p-4">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <div className="text-center">
              <h3 className="mb-2 text-sm font-semibold sm:text-base">{t("startConversation")}</h3>
              <p className="mb-4 text-xs text-muted-foreground sm:text-sm">{t("askAnything")}</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestedQuestion(question)}
                  className="text-xs"
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-lg px-3 py-2 sm:max-w-[80%] sm:px-4 ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {message.parts.map((part, index) => {
                    if (part.type === "text") {
                      return (
                        <p key={index} className="text-sm leading-relaxed whitespace-pre-wrap">
                          {part.text}
                        </p>
                      )
                    }
                    return null
                  })}
                </div>
                {message.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary/10">
                    <User className="h-4 w-4 text-secondary" />
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="border-t p-3 sm:p-4">
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            placeholder={t("askPlaceholder")}
            disabled={status === "in_progress"}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={status === "in_progress"}>
            <Send className="h-4 w-4" />
            <span className="sr-only">{t("send")}</span>
          </Button>
        </div>
      </form>
    </Card>
  )
}
