"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type Language = "en" | "pt"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    // Navigation
    home: "Home",
    experience: "Experience",
    projects: "Projects",
    skills: "Skills",
    contact: "Contact",
    dataEngineer: "Data Engineer",

    // Homepage
    helloTitle: "Hello, I'm a",
    homeSubtitle:
      "Specializing in building scalable data pipelines, ETL systems, and analytics infrastructure. Ask me anything about my experience, projects, or technical skills.",
    yearsExp: "Years Experience",
    projectsCompleted: "Projects Completed",
    techMastered: "Technologies Mastered",

    // Chat Interface
    aiAssistant: "AI Portfolio Assistant",
    typing: "Typing...",
    online: "Online",
    startConversation: "Start a conversation",
    askAnything: "Ask me anything about my background, skills, or projects",
    askPlaceholder: "Ask me anything...",
    send: "Send message",

    // Suggested Questions
    q1: "What's your experience with data pipelines?",
    q2: "Tell me about your technical skills",
    q3: "What projects have you worked on?",
    q4: "What tools do you use for ETL?",

    // Experience Page
    experienceTitle: "Professional Experience",
    experienceSubtitle: "My journey in data engineering and analytics",

    // Projects Page
    projectsTitle: "Featured Projects",
    projectsSubtitle: "Showcasing my work in data engineering and analytics",

    // Skills Page
    skillsTitle: "Technical Skills",
    skillsSubtitle: "Technologies and tools I work with",

    // Contact Page
    contactTitle: "Get In Touch",
    contactSubtitle: "Let's discuss how we can work together",
  },
  pt: {
    // Navigation
    home: "Início",
    experience: "Experiência",
    projects: "Projetos",
    skills: "Habilidades",
    contact: "Contato",
    dataEngineer: "Engenheiro de Dados",

    // Homepage
    helloTitle: "Olá, sou um",
    homeSubtitle:
      "Especializado em construir pipelines de dados escaláveis, sistemas ETL e infraestrutura de análise. Pergunte-me qualquer coisa sobre minha experiência, projetos ou habilidades técnicas.",
    yearsExp: "Anos de Experiência",
    projectsCompleted: "Projetos Concluídos",
    techMastered: "Tecnologias Dominadas",

    // Chat Interface
    aiAssistant: "Assistente de Portfólio IA",
    typing: "Digitando...",
    online: "Online",
    startConversation: "Iniciar uma conversa",
    askAnything: "Pergunte-me qualquer coisa sobre minha formação, habilidades ou projetos",
    askPlaceholder: "Pergunte-me qualquer coisa...",
    send: "Enviar mensagem",

    // Suggested Questions
    q1: "Qual é sua experiência com pipelines de dados?",
    q2: "Fale sobre suas habilidades técnicas",
    q3: "Em quais projetos você trabalhou?",
    q4: "Quais ferramentas você usa para ETL?",

    // Experience Page
    experienceTitle: "Experiência Profissional",
    experienceSubtitle: "Minha jornada em engenharia de dados e análise",

    // Projects Page
    projectsTitle: "Projetos em Destaque",
    projectsSubtitle: "Mostrando meu trabalho em engenharia de dados e análise",

    // Skills Page
    skillsTitle: "Habilidades Técnicas",
    skillsSubtitle: "Tecnologias e ferramentas com as quais trabalho",

    // Contact Page
    contactTitle: "Entre em Contato",
    contactSubtitle: "Vamos discutir como podemos trabalhar juntos",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
